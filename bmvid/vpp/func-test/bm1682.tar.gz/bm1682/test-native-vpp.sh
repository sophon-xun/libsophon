date >> result.txt

###################################################
# vpp_boarder
###################################################

echo "vpp_border"
function vpp_border()
{
    ./vpp_border 1920 1080 bgr-org-opencv-bmp3.bin 32 32 32 32 $1 $2 out.bmp

    md5sum -c vpp_border.md5

    result="$?"

    if [ "$result" -ne 0 ]; then
        echo "vpp_border $1 $2 -- error" >> result.txt
    else
        echo "vpp_border $1 $2-- okay" >> result.txt
    fi

    rm out.bmp
}

vpp_border 0 0
vpp_border 0 1
vpp_border 1 0
vpp_border 1 1
function vpp_border_nodevfd()
{
    ./vpp_border_nodevfd 1920 1080 bgr-org-opencv-bmp3.bin 32 32 32 32 $1 $2 out.bmp

    md5sum -c vpp_border.md5

    result="$?"

    if [ "$result" -ne 0 ]; then
        echo "vpp_border_nodevfd $1 $2 -- error" >> result.txt
    else
        echo "vpp_border_nodevfd $1 $2-- okay" >> result.txt
    fi

    rm out.bmp
}

vpp_border_nodevfd 0 0
vpp_border_nodevfd 0 1
vpp_border_nodevfd 1 0
vpp_border_nodevfd 1 1
####################################################
## vpp_cropsingle
####################################################

echo "vpp_cropsingle"
#vpp_cropsingle 1920 1080 bgr-org-opencv.bin out0.bmp out1.bmp out2.bmp
#
#md5sum -c vpp_cropsingle.md5
#
#result="$?"
#
#if [ "$result" -ne 0 ]; then
#	echo "vpp_cropsingle -- error" >> result.txt
#else
#	echo "vpp_cropsingle -- okay" >> result.txt
#fi
#
#rm out0.bmp out1.bmp out2.bmp

function vpp_cropsingle()
{
    ./vpp_cropsingle 1920 1080 5 bgr-org-opencv.bin $1 $2 5 out0.bmp out1.bmp out2.bmp

    md5sum -c vpp_cropsingle.md5

    result="$?"

    if [ "$result" -ne 0 ]; then
        echo "vpp_cropsingle $1 $2 -- error" >> result.txt
    else
        echo "vpp_cropsingle $1 $2 -- okay" >> result.txt
    fi

    rm out0.bmp out1.bmp out2.bmp
}

vpp_cropsingle 0 0 
vpp_cropsingle 0 1 
vpp_cropsingle 1 0 
vpp_cropsingle 1 1 
#####################################################
### vpp_cropmulti
#####################################################
#
echo "vpp_cropmulti"
##vpp_cropmulti 1920 1080 bgr-org-opencv.bin bgr-org-opencv-10.bin bgr-org-opencv-222.bin out0.bmp out1.bmp out2.bmp
##
##md5sum -c vpp_cropmulti.md5
##
##result="$?"
##
##if [ "$result" -ne 0 ]; then
##	echo "vpp_cropmulti -- error" >> result.txt
##else
##	echo "vpp_cropmulti -- okay" >> result.txt
##fi
##
##rm out0.bmp out1.bmp out2.bmp
#
function vpp_cropmulti()
{
    ./vpp_cropmulti 1920 1080 bgr-org-opencv.bin bgr-org-opencv-10.bin bgr-org-opencv-222.bin $1 $2 out0.bmp out1.bmp out2.bmp

    md5sum -c vpp_cropmulti.md5

    result="$?"

    if [ "$result" -ne 0 ]; then
        echo "vpp_cropmulti $1 $2 -- error" >> result.txt
    else
        echo "vpp_cropmulti $1 $2 -- okay" >> result.txt
    fi

    rm out0.bmp out1.bmp out2.bmp
}

vpp_cropmulti 0 0
vpp_cropmulti 0 1
vpp_cropmulti 1 0
vpp_cropmulti 1 1

#####################################################
### vpp_resize
#####################################################
# vpp_resize_0
echo "vpp_resize"

function resize_rgb()
{
    ./vpp_resize 1920 1080 bgr-org-opencv.bin $1 $2 5 5 1280 720 out.bmp
    
    md5sum -c vpp_resize_0.md5
    
    result="$?"
    
    if [ "$result" -ne 0 ]; then
        echo "vpp_resize 1920 1080 bgr-org-opencv.bin $1 $2 5 5 1280 720 out.bmp -- error" >> result.txt
    else
        echo "vpp_resize 1920 1080 bgr-org-opencv.bin $1 $2 5 5 1280 720 out.bmp -- okay" >> result.txt
    fi
    
    rm out.bmp
}

resize_rgb 0 0
resize_rgb 0 1
resize_rgb 1 0
resize_rgb 1 1

function resize_yuv420()
{
    ./vpp_resize 1920 1080 i420p-1080p.yuv $1 $2 0 0 1280 720 out.yuv
    
    md5sum -c vpp_resize_1.md5
    
    result="$?"
    
    if [ "$result" -ne 0 ]; then
        echo "vpp_resize 1920 1080 i420p-1080p.yuv $1 $2 0 0 1280 720 out.yuv -- error" >> result.txt
    else
        echo "vpp_resize 1920 1080 i420p-1080p.yuv $1 $2 0 0 1280 720 out.yuv -- okay" >> result.txt
    fi
    
    rm out.yuv
}

resize_yuv420 0 0
resize_yuv420 0 1
resize_yuv420 1 0
resize_yuv420 1 1
######################################################
#### vpp_splitfd
######################################################

echo "vpp_splittobgr"
./vpp_splittobgr 1920 1080 bgr-org-opencv.bin b.bmp g.bmp r.bmp

md5sum -c vpp_splittobgr.md5

result="$?"

if [ "$result" -ne 0 ]; then
	echo "vpp_splittobgr -- error" >> result.txt
else
	echo "vpp_splittobgr -- okay" >> result.txt
fi

rm b.bmp g.bmp r.bmp

######################################################
#### vpp_splitcomponent
######################################################
echo "vpp_splittorgb"
function split_bgr_to_rgbp()
{
    ./vpp_splittorgb 1920 1080 bgr-org-opencv.bin $1 $2 r.bmp g.bmp b.bmp
    
    md5sum -c vpp_splittorgb.md5
    
    result="$?"
    
    if [ "$result" -ne 0 ]; then
        echo "vpp_splittorgb 1920 1080 bgr-org-opencv.bin $1 $2 r.bmp g.bmp b.bmp -- error" >> result.txt
    else
        echo "vpp_splittorgb 1920 1080 bgr-org-opencv.bin $1 $2 r.bmp g.bmp b.bmp -- okay" >> result.txt
    fi
    
    rm  r.bmp g.bmp b.bmp
}

split_bgr_to_rgbp 0 0
split_bgr_to_rgbp 0 1
split_bgr_to_rgbp 1 0
split_bgr_to_rgbp 1 1
#####################################################
### vpp_convert
#####################################################
echo "vpp_convert"
function convert_420p_to_bgr()
{
    ./vpp_convert 1920 1080 img2.yuv $1 $2 0 5 out.bmp
    
    md5sum -c vpp_convert_0.md5
    
    result="$?"
    
    if [ "$result" -ne 0 ]; then
    	echo "vpp_convert 1920 1080 img2.yuv $1 $2 0 5 out.bmp -- error" >> result.txt
    else
    	echo "vpp_convert 1920 1080 img2.yuv $1 $2 0 5 out.bmp -- okay" >> result.txt
    fi
    
    rm out.bmp
}

function convert_nv12_to_bgr()
{
    ./vpp_convert 1920 1080 img1.nv12 $1 $2 7 5 out.bmp
    
    md5sum -c vpp_convert_1.md5
    
    result="$?"
    
    if [ "$result" -ne 0 ]; then
        echo "vpp_convert 1920 1080 img1.nv12 $1 $2 7 5 out.bmp -- error" >> result.txt
    else
        echo "vpp_convert 1920 1080 img1.nv12 $1 $2 7 5 out.bmp -- okay" >> result.txt
    fi
    
    rm out.bmp
}

function convert_nv12_to_420p()
{
    ./vpp_convert 1920 1080 img1.nv12 $1 $2 7 0 out.yuv
    md5sum -c vpp_convert_2.md5
    
    result="$?"
    
    if [ "$result" -ne 0 ]; then
        echo "vpp_convert 1920 1080 img1.nv12 $1 $2 7 0 out.yuv -- error" >> result.txt
    else
        echo "vpp_convert 1920 1080 img1.nv12 $1 $2 7 0 out.yuv -- okay" >> result.txt
    fi
    
    rm out.yuv
}
# vpp_convert, yuv420p to bgr
convert_420p_to_bgr 0 0
convert_420p_to_bgr 0 1
convert_420p_to_bgr 1 0
convert_420p_to_bgr 1 1

# vpp_convert, nv12 to bgr
convert_nv12_to_bgr 0 0
convert_nv12_to_bgr 0 1
convert_nv12_to_bgr 1 0
convert_nv12_to_bgr 1 1

# vpp_convert, nv12 to yuv420p
convert_nv12_to_420p 0 0
convert_nv12_to_420p 0 1
convert_nv12_to_420p 1 0
convert_nv12_to_420p 1 1

#####################################################
### vpp_iondemo
#####################################################
echo "vpp_iondemo"
function vpp_iondemo()
{
    ./vpp_iondemo 1920 1080 bgr-org-opencv-bmp3.bin 32 32 32 32 $1 $2 out.bmp
    
    md5sum -c vpp_iondemo.md5
    
    result="$?"
    
    if [ "$result" -ne 0 ]; then
    	echo "vpp_iondemo 1920 1080 bgr-org-opencv-bmp3.bin 32 32 32 32 $1 $2 out.bmp -- error" >> result.txt
    else
    	echo "vpp_iondemo 1920 1080 bgr-org-opencv-bmp3.bin 32 32 32 32 $1 $2 out.bmp -- okay" >> result.txt
    fi
    
    rm out.bmp
}
vpp_iondemo 0 0
vpp_iondemo 0 1
vpp_iondemo 1 0
vpp_iondemo 1 1

